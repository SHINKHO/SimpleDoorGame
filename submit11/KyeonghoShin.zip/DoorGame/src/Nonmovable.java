
public interface Nonmovable  {
	abstract int findDistance(int[] dest);

}
