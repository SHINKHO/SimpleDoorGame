
public enum Status {
	Gold,
	Hp,
	Speed,Fortune,
}
