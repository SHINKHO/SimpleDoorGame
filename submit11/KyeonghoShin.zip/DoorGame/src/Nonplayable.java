
public interface Nonplayable extends PerTickofGame {
	
	public abstract int[] getWhere();
	public abstract Nonplayable copy();
	
}
