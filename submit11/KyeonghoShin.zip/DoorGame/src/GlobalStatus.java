import java.util.Set;

public class GlobalStatus {
	private int timeFlowBase;
	private double misfortuneBase;
	private int currentTime;
	
	
}
