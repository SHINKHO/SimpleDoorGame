
public interface PerTickofGame {
	public abstract void perTurn();
}
