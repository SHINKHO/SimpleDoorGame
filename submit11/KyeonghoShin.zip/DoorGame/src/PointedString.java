
public class PointedString {
	private int[] point;
	private String string;
	public PointedString(int[] point, String string) {
		super();
		this.point = point;
		this.string = string;
	}
	public int[] getPoint() {
		return point;
	}
	public String getString() {
		return string;
	}
	
	
}
